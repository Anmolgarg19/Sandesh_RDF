$(function() {
    $('#btnFindByTheme').click(function() {
        
	document.getElementById("header_names").innerHTML = "" ;
	document.getElementById("table_names").setAttribute("value", "none");
	//alert(theme);
	//document.getElementById("btnFindByTheme").setAttribute("value",theme);
        $.ajax({
            url: '/findByTheme',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
		//alert(data);
		//document.getElementById("table_names").setAttribute("value",obj.getAttribute("id"));
                console.log(response);
		console.log("Hi..ANMOL");
                var tableThemes = response.split("[")[1].split("]")[0].split(",");
                console.log(tableThemes)
		var set_id = " id = \" "
                var value_tag = "value = \""
                var on_click = "onclick = \"getdata(value)\"" 
                var html = "";
                for (var i = 0; i < tableThemes.length; i++) 
		{
		    table_name=tableThemes[i].split("/")[tableThemes[i].split("/").length-1].split("#")[0];
                    value_tag += tableThemes[i]
                    value_tag += "\""
		    set_id = set_id + table_name + "\"";
                    html+="<tr "+ "class = \"clickable-row\" >";
		    var checkbox=" <input type='checkbox' id = '"+table_name+"' onchange='func("+tableThemes[i]+", this)' value='Select' />";
		    console.log("Checkbox..Check?");
		    console.log(checkbox);
		    
                    html+="<td"+" "+on_click+"  "+value_tag  +">"+checkbox+"<a>"+table_name+"</a>"+"</td>";

                    html+="</tr>";

                }
                ///html+="</tbody>";
		console.log("Table Name Html..Check");
		console.log(html);
                document.getElementById("table_names").innerHTML = html;
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});


function func(tablethemename, obj) 
{

		
	if($(obj).is(":checked")){
		var new_obj = document.getElementById("table_names").getAttribute("value");
		if(new_obj == "none"){
			
			document.getElementById("table_names").setAttribute("value",obj.getAttribute("id"));

		}
		else{
		
			document.getElementById(new_obj).checked = false;			
			document.getElementById("table_names").setAttribute("value",obj.getAttribute("id"));
		
		
		}
		$.ajax({
            		url: '/getHeaderByTableName',
            		data: tablethemename,
              		type: 'POST',
           		success: function(response) 
			{
			document.getElementById("header_names").innerHTML = "" ;
			var html="";
			var themename = response.split("[")[1].split("]")[0].split(",");
			console.log("ThemeNAme....check")
			console.log(themename);
			var data_html = "<tr id = \"data_rows\" >";
			for (var i = 0; i < themename.length; i++)
				{
					html+="<td>";
					var temp=themename[i].split("\"");
					html+=temp[1];
					html+="&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp";
					html+="</td>";
					data_html+="<td id = \""+temp[1]+"\"> </td>"; 
				}
			data_html += "</tr>";							
	
			console.log(html);
			document.getElementById("header_names").innerHTML =html ;


			var theme = document.getElementById('inputTheme').value;
			var new_data = tablethemename+";"+theme;
			$.ajax({
            			url: '/gettablerows',
            			data: new_data,
		      		type: 'POST',
		   		success: function(response) 
				{
				console.log("in second"  + response);
				
				}
	 		});


			}



	 	});


		





	}
	else{
		document.getElementById("header_names").innerHTML = "" ;
		document.getElementById("table_names").setAttribute("value", "none");
	}


	
}




